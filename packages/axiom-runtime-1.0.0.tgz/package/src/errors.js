class Errors{start(){process.on('uncaughtException',e=>console.error({event:'exception',message:e.message}));process.on('unhandledRejection',e=>console.error({event:'rejection',message:String(e)}))}}
module.exports=Errors;
