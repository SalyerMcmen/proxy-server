class Memory{constructor(){this.timer=null}start(){this.timer=setInterval(()=>{let m=process.memoryUsage();if(m.heapUsed>100*1024*1024)console.log({event:'memory_warning',heapUsed:m.heapUsed})},5000)}stop(){clearInterval(this.timer)}}
module.exports=Memory;
