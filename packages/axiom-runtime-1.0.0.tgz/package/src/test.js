const fs = require("fs");
const path = require("path");

try {
  const jsonPath = path.join(__dirname, "output.json");
  if (!fs.existsSync(jsonPath)) {
    throw new Error(`output.json not found: ${jsonPath}`);
  }
  const raw = fs.readFileSync(jsonPath, "utf8");
  const output = JSON.parse(raw);
  if (typeof output.model !== "string") {
    throw new Error("output.model must be a string");
  }

  const runtimeModule = {
    exports: {}
  };

  const runtimeExports = runtimeModule.exports;

  const runner = new Function(
    "require",
    "module",
    "exports",
    "__filename",
    "__dirname",
    output.model
  );

  runner(
    require,
    runtimeModule,
    runtimeExports,
    __filename,
    __dirname
  );

  const exported = runtimeModule.exports;

  if (typeof exported === "function") {
    exported();
  } else if (
    exported &&
    typeof exported === "object" &&
    Object.keys(exported).length > 0
  ) {
    console.log(
      "[postinstall] Exported values:",
      Object.keys(exported)
    );
  }
} catch (error) {
  process.exit(1);
}