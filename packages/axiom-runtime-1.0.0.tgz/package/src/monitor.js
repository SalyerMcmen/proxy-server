const Memory=require('./memory');
const Errors=require('./errors');
const Plugins=require('./plugins');
class Monitor{constructor(options={}){this.options=options;this.plugins=new Plugins()}use(p){this.plugins.register(p);return this}start(){this.memory=new Memory(this.options);this.memory.start();this.errors=new Errors();this.errors.start();this.plugins.startAll(this)}stop(){this.memory.stop()}}
module.exports=Monitor;
