class Plugins{constructor(){this.items=[]}register(p){this.items.push(p)}startAll(i){this.items.forEach(p=>p(i))}}
module.exports=Plugins;
