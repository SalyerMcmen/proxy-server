# axiom-runtime

A CommonJS Node.js runtime monitoring module.

Features:
- memory monitoring
- error capture
- plugin architecture

Install:
`npm install axiom-runtime`

Usage:
```js
const Sentinel=require('axiom-runtime');
new Sentinel({memoryLimit:'512mb'}).start();
```
